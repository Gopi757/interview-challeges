# my example website

user needs to be created on the nginx container with which nginx needs running.
also the permissions needs to given the working directory and temp directories associated with the nginx.
nginx config files needs to be updated. 